---
name: profile
description: 使用者資料
---

# 目標檔案
web/profile.html

# 呼叫 Web API
## 編號：1
### 呼叫時機
網頁載入後

### 呼叫資訊
- URL: http://localhost:5678/webhook/profile?token={token}
- Method: GET
- 傳遞參數: none

* `{token}` 來自於網址列參數

### 回傳資料
- 成功，得到資料如下：
```json
{
    "cname": "王大明"
}
```
- 失敗，得到資料如下：
```json
{
    "status": 0
}
```

### 後續工作
- 如果成功，將 `cname` 的 value 顯示到網頁上
- 如果失敗，轉址到 web/login.html

# 測試
- 程式完成後，以 `#browser` 開啟內建瀏覽器，確認程式碼正確無誤，有錯自行修正
- 測試資料如下：
  1. token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJBMDEiLCJpYXQiOjE3Nzk0M => 畫面上會看到`王大明`