---
name: login
description: 處理 login.html
---

# 目標檔案
web/login.html

# 呼叫 Web API
## 編號：1
### 呼叫時機
`Sign In` 按鈕按下後

### 呼叫資訊
- URL: http://localhost:5678/webhook/login
- Method: POST
- 傳遞參數: JSON payload 格式，如下：
```json
{
    "uid": "{uid}",
    "password": "{password}"
}
```

### 回傳資料
- 登入成功，得到資料如下：
```json
{
    "status": 1,
    "token": "askljflaskdjf"
}
```
- 登入失敗，得到資料如下：
```json
{
    "status": 0,
    "token": ""
}
```

### 後續工作
- 如果登入成功，進入 `web/profile.html?token={token}`
- 如果登入失敗，以 alert() 送出登入失敗訊息

# 測試
- 程式完成後，以 `#browser` 開啟內建瀏覽器，確認程式碼正確無誤，有錯自行修正
- 測試資料如下：
  uid=A01, password=1234 => 登入成功
  uid=A02, password=5678 => 登入成功