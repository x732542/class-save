# SPEC_login.md

來源檔案: `web/login.html`

---
## API 互動邏輯 (fetch)
針對頁面中每一個 API 呼叫（fetch/XHR），填寫以下資訊。
**重要：必須實際執行測試或查找現有 JSON 範例檔案來取得真實回傳結構。**

### 1. 使用者登入驗證
* **請求資訊**
  - Method: `POST`
  - URL: `http://localhost:5678/webhook/login`
  - Headers: `Content-Type: application/json`
  - Payload (Request Body):
    ```json
    {
      "uid": "使用者輸入的員工編號，例如 A01",
      "password": "使用者輸入的密碼"
    }
    ```

* **回應內容 (Response)**
  - HTTP Status: `200 OK`
  - Body 範例（成功，實測）:
    ```json
    {
      "status": 1
    }
    ```
  - Body 範例（失敗，實測）:
    ```json
    {
      "status": 0
    }
    ```
  - 資料解讀與處理邏輯：
    - 前端於 Sign In 按鈕送出時呼叫此 API。
    - 送出前按鈕會暫時 disabled，並顯示 Signing In...，避免重複提交。
    - 當 `status` 為 `1` 時，前端導向 `profile.html`。
    - 當 `status` 為 `0`，或發生非 2xx/網路錯誤時，前端顯示 `alert('登入失敗')`。

---
